# Third-party notices

Jill-EX is licensed under the PolyForm Noncommercial License 1.0.0 (see
`LICENSE.md`).  This file lists the third-party components used by the port and
the tools, and repeats the notices their licenses require when binaries are
distributed.

Nothing in this file grants rights to the original Jill of the Jungle,
Jill Goes Underground, Jill Saves the Prince or Onesimus game data.  Those
assets remain the property of their owners, and no game data is distributed
with this repository.

## Redistributing a build

Ship `LICENSE.md` and this file alongside the executable.  The PolyForm terms
require everyone who receives the software to get the licence or its URL and
the `Required Notice` line, and the SDL2 zlib licence requires its notice in
the accompanying documentation.

## Compiled into the game executable

### SDL2

The game links SDL2 and ships `SDL2.dll` beside the executable.

```
Copyright (C) 1997-2024 Sam Lantinga <slouken@libsdl.org>

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
```

### stb_image

Public domain (Unlicense) or MIT, at your option.

```
Copyright (c) 2017 Sean Barrett and contributors

This software is available under two licenses.  Choose whichever you prefer.

Alternative A - MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Alternative B - Unlicense

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or distribute this
software, either in source code form or as a compiled binary, for any purpose,
commercial or non-commercial, and by any means.

In jurisdictions that recognize copyright laws, the author or authors of this
software dedicate any and all copyright interest in the software to the public
domain.  We make this dedication for the benefit of the public at large and to
the detriment of our heirs and successors.  We intend this dedication to be an
overt act of relinquishment in perpetuity of all present and future rights to
this software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <https://unlicense.org>
```

### stb_vorbis

Public domain (Unlicense) or MIT, at your option.  Copyright Sean Barrett and
contributors.  The full dual-license statement is at the end of
`port/src/third_party/stb_vorbis.c`.

### dr_mp3

Public domain (Unlicense) or MIT-0, at your option.

```
Copyright 2018-2024 David Reid

MIT No Attribution

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

The Unlicense alternative is the same text shown under stb_image.

### miniz

MIT or Unlicense, at your option.

```
Copyright 2013-2014 RAD Game Tools and Valve Software
Copyright 2010-2014 Rich Geldreich and Tenacious Software LLC

All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

### Microsoft Media Foundation

M4A/AAC decoding uses the Media Foundation APIs that ship with Windows
(`mfplat`, `mfreadwrite`, `mfuuid`, `ole32`).  These are operating-system
components; no Microsoft code is redistributed with this project.

## Used by the Python tools

The extractor and importer import these packages; they are installed
separately and are not bundled in this repository.

| Package | License | Copyright |
| --- | --- | --- |
| Pillow | MIT-CMU | Copyright (c) 2010 by Jeffrey A. Clark and contributors |
| Capstone | BSD 3-Clause | Copyright (c) 2013 COSEINC |
| numpy | BSD 3-Clause (with permissive bundled components) | Copyright (c) 2005-2024 NumPy Developers |
| Python / Tk | Python Software Foundation License | Copyright (c) Python Software Foundation |

The full license text for each package is included with its installed
distribution and is also available from the package's project page.

## Game content and trademarks

Jill of the Jungle, Jill Goes Underground, Jill Saves the Prince and
Onesimus: A Quest for Freedom, together with their artwork, levels, music and
characters, are the property of their respective owners.  This project is an
unaffiliated engine reimplementation and does not grant any license to that
content.

Users must supply their own legally obtained copy of the original games.  Any
assets extracted, rendered or rebuilt from those games remain subject to the
original owners' rights and are not covered by the PolyForm license.
